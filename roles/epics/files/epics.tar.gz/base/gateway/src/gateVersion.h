/*************************************************************************\
* Copyright (c) 2002 The University of Chicago, as Operator of Argonne
* National Laboratory.
* Copyright (c) 2002 Berliner Speicherring-Gesellschaft fuer Synchrotron-
* Strahlung mbH (BESSY).
* Copyright (c) 2002 The Regents of the University of California, as
* Operator of Los Alamos National Laboratory.
* This file is distributed subject to a Software License Agreement found
* in the file LICENSE that is included with this distribution. 
\*************************************************************************/
#ifndef _GATEVERSION_H_
#define _GATEVERSION_H_

/*+*********************************************************************
 *
 * File:       gateVersion.h
 * Project:    CA Proxy Gateway
 *
 * Descr.:     Gateway Version Information
 *
 * Author(s):  J. Kowalkowski, J. Anderson, K. Evans (APS)
 *             R. Lange (ITER), Gasper Jansa (cosylab),
 *             Dirk Zimoch (PSI)
 *
 *********************************************************************-*/

#define GATEWAY_VERSION       2
#define GATEWAY_REVISION      0
#define GATEWAY_MODIFICATION  6
#define GATEWAY_UPDATE_LEVEL  0

#define GATEWAY_VERSION_STRING "PV Gateway Version 2.0.6.0"

#define GATEWAY_CREDITS_STRING  \
          "Originally developed at Argonne National Laboratory and BESSY\n\n" \
          "Authors: Jim Kowalkowski, Janet Anderson, Kenneth Evans, Jr. (APS),\n" \
          "   Ralph Lange (ITER), Gasper Jansa (cosylab), and Dirk Zimoch (PSI)\n\n"
#endif

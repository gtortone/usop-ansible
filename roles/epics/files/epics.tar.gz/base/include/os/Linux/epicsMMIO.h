
#include "epicsMMIODef.h"

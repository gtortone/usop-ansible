/* menuSimm.h generated from menuSimm.dbd */

#ifndef INC_menuSimm_H
#define INC_menuSimm_H

typedef enum {
    menuSimmNO                      /* NO */,
    menuSimmYES                     /* YES */,
    menuSimmRAW                     /* RAW */
} menuSimm;
#define menuSimm_NUM_CHOICES 3


#endif /* INC_menuSimm_H */

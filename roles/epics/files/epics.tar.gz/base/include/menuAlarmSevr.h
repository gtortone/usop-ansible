/* menuAlarmSevr.h generated from menuAlarmSevr.dbd */

#ifndef INC_menuAlarmSevr_H
#define INC_menuAlarmSevr_H

typedef enum {
    menuAlarmSevrNO_ALARM           /* NO_ALARM */,
    menuAlarmSevrMINOR              /* MINOR */,
    menuAlarmSevrMAJOR              /* MAJOR */,
    menuAlarmSevrINVALID            /* INVALID */
} menuAlarmSevr;
#define menuAlarmSevr_NUM_CHOICES 4


#endif /* INC_menuAlarmSevr_H */

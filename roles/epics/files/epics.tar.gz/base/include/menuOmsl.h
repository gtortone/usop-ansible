/* menuOmsl.h generated from menuOmsl.dbd */

#ifndef INC_menuOmsl_H
#define INC_menuOmsl_H

typedef enum {
    menuOmslsupervisory             /* supervisory */,
    menuOmslclosed_loop             /* closed_loop */
} menuOmsl;
#define menuOmsl_NUM_CHOICES 2


#endif /* INC_menuOmsl_H */

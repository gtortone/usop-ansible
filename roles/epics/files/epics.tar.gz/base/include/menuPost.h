/* menuPost.h generated from menuPost.dbd */

#ifndef INC_menuPost_H
#define INC_menuPost_H

typedef enum {
    menuPost_OnChange               /* On Change */,
    menuPost_Always                 /* Always */
} menuPost;
#define menuPost_NUM_CHOICES 2


#endif /* INC_menuPost_H */

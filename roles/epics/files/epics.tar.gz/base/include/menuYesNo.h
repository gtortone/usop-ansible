/* menuYesNo.h generated from menuYesNo.dbd */

#ifndef INC_menuYesNo_H
#define INC_menuYesNo_H

typedef enum {
    menuYesNoNO                     /* NO */,
    menuYesNoYES                    /* YES */
} menuYesNo;
#define menuYesNo_NUM_CHOICES 2


#endif /* INC_menuYesNo_H */
